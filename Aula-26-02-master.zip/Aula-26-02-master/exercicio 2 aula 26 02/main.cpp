#include <stdio.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() 
{
	//system("cls");
	
	int A=0;
	printf ("informe um valor A inteiro:\n");
	scanf ("%i",& A);
	printf("O valor de A eh: %i\n", A);
	

	
	
	
	return 0;
}
