// C�digo em linguagem C
#include<stdio.h>
int main() 
{
	int A=5;
	int B=4;
	
	if(A>B)
	{
		printf("A e maior que B!\n");
			
	}

	else
	 { 
		if(A<B)
		{
			printf("B e maior que A!\n");
		}
		else
		  {
			printf("B e igual a A!\n");
		  }
     }
}
	
